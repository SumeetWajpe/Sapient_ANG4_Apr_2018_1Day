var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var strMsg = "Hello World !"; // type inference !
// strMsg = 100;
console.log(strMsg);
// if(true){
//     let x = 100;
//     let x = 200;
//     if(true){
//         console.log(x);        
//     }
// }
// type annotation !
var x;
x = 100;
var boolType;
var str;
var obj;
obj = 100;
obj = "Hi !";
obj = { name: 'Sapient !', location: 'Bengaluru' };
obj = ["BMW", "AUDI", "FERRARI"];
var cars = new Array("TATA", "HYUNDAI", "MARUTI");
// Functions !
function Addition(x, y) {
    return x + y;
}
var result = Addition(20, 30);
// function PrintBooks(author?:string,title?:string,noOfPages?:number){
// }
// PrintBooks();
// PrintBooks("Dr. APJ Abdul Kalam","India 2020");
function PrintBooks(title, noOfPages, author) {
    if (author === void 0) { author = "Unknown"; }
    console.log(author, noOfPages, title);
}
PrintBooks("Dr. APJ Abdul Kalam", 800, "India 2020");
// Classes !
var Car = /** @class */ (function () {
    function Car(theName, theSpeed, theId) {
        if (theName === void 0) { theName = "i20"; }
        if (theSpeed === void 0) { theSpeed = 200; }
        if (theId === void 0) { theId = 1; }
        this.id = theId;
        this.name = theName;
        this.speed = theSpeed;
    }
    Car.prototype.Accelerate = function () {
        return (this.name + "  is running at " + this.speed + " kmph !");
    };
    return Car;
}());
// let carObj = new Car();
// carObj.Accelerate();
var JamesBondCar = /** @class */ (function (_super) {
    __extends(JamesBondCar, _super);
    function JamesBondCar(theName, theSpeed, theId, canItFly, beInvisible) {
        var _this = _super.call(this, theName, theSpeed, theId) || this;
        _this.canBeInvisible = beInvisible;
        _this.canFly = canItFly;
        return _this;
    }
    JamesBondCar.prototype.Accelerate = function () {
        return _super.prototype.Accelerate.call(this) + " Can It Fly ? " + this.canFly;
    };
    return JamesBondCar;
}(Car));
var jbc = new JamesBondCar("Houston", 500, 7, true, true);
console.log(jbc.Accelerate());
