
let strMsg = "Hello World !"; // type inference !
// strMsg = 100;
console.log(strMsg);

// if(true){
//     let x = 100;
//     let x = 200;

//     if(true){
//         console.log(x);        
//     }
// }

// type annotation !

var x:number;
x = 100;
var boolType:boolean;
var str:string;
var obj:any;
obj = 100;
obj = "Hi !";
obj = {name:'Sapient !',location:'Bengaluru'};
obj = ["BMW","AUDI","FERRARI"];

var cars:Array<string> = new Array<string>("TATA","HYUNDAI","MARUTI");


// Functions !

function Addition(x:number,y:number):number{
    return x + y;
}

var result:number = Addition(20,30);


// function PrintBooks(author?:string,title?:string,noOfPages?:number){

// }
// PrintBooks();
// PrintBooks("Dr. APJ Abdul Kalam","India 2020");



function PrintBooks(title:string,noOfPages:number,author:string="Unknown"){
     console.log(author,noOfPages,title);
}

PrintBooks("Dr. APJ Abdul Kalam",800,"India 2020");

// Classes !

class Car{
    private id:number;
    name:string;
    speed:number;

    constructor(theName:string="i20",theSpeed:number=200,theId:number=1){
            this.id = theId;
            this.name = theName;
            this.speed = theSpeed;
    }

    Accelerate():string{
        return (this.name + "  is running at " + this.speed + " kmph !")
    }
}
// let carObj = new Car();
// carObj.Accelerate();
class JamesBondCar extends Car{
    canFly:boolean;
    canBeInvisible:boolean;
    constructor(theName:string,theSpeed:number,theId:number,canItFly:boolean,beInvisible:boolean){
            super(theName,theSpeed,theId);
            this.canBeInvisible = beInvisible;
            this.canFly = canItFly;
    }
    Accelerate():string{
        return super.Accelerate() + " Can It Fly ? " + this.canFly;
    }
}

var jbc = new JamesBondCar("Houston",500,7,true,true);
console.log(jbc.Accelerate());