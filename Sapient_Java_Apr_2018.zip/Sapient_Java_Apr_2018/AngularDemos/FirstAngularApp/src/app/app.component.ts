import { Component } from '@angular/core';
import {CourseService} from './course.service';

@Component({
  selector: 'app-root',
  // template:`
 
  // `,
   templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers:[CourseService]
})
export class AppComponent {
  heading:string = "List Of Courses";
  courses=[];
  title = 'app';
  ImageUrl:string = "https://www.w3schools.com/angular/pic_angular.jpg";

  IsSuccess:boolean=false;

  // Injected !
  constructor(public srvObj:CourseService){
      console.log(this.srvObj.getRandomCourse())
      this.courses = this.srvObj.listOfCourses;
  }

  ChangeHeading(e:any){
   this.heading = (e.target.value); 
  }
}
