import {Component,Input} from '@angular/core';


@Component({
    selector:`course`,
    template:`
    <h1> {{details.name}}  </h1>
    <b> Duration : </b> {{details.duration}}
    `
})
export class CourseComponent {
     @Input('coursedetails')   details:any= {name:'Angular',duration:'3 Days'};
}