export class CourseService{
    listOfCourses=[
        {name:"ReactJS",duration:'3 Days'},
      {name : "KnockoutJS",duration:'2 Days'},
      {name : "Angular",duration:'2 Days'},
      {name : "Node",duration:'2 Days'}  
    ];

    getRandomCourse(){
            return this.listOfCourses[Math.floor(Math.random() * this.listOfCourses.length)];
    }
}